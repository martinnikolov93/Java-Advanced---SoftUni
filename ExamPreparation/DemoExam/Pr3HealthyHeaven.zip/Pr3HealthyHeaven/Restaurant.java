package ExamPreparation.DemoExam.Pr3HealthyHeaven;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Restaurant {
    private String name;
    private ArrayList<Salad> data;

    public Restaurant(String name) {
        this.name = name;
        this.data = new ArrayList<>();
    }

    public void add(Salad salad){
        this.data.add(salad);
    }

    public boolean buy(String name){
        boolean isRemoved = false;

        for (int i = 0; i < this.data.size(); i++) {
            String nameSalad = this.data.get(i).getName();
            if (name.equals(nameSalad)){
                this.data.remove(i);
                isRemoved = true;
            }
        }

        return isRemoved;
    }

    public String getHealthiestSalad(){
        String healthiestSalad = "";
        int minCalories = Integer.MAX_VALUE;

        for (int i = 0; i < this.data.size(); i++) {
            Salad salad = this.data.get(i);

            if (salad.getTotalCalories() < minCalories){
                minCalories = salad.getTotalCalories();
                healthiestSalad = salad.getName();
            }
        }

        return healthiestSalad;
    }

    public String generateMenu(){
        String menu = this.name + " have " + this.data.size() + " salads:";
        for (Salad salad : this.data) {
            menu += "\n" + salad.toString();
        }
        
        return menu;
    }
}
