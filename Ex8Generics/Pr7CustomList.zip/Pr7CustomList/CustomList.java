package Ex8Generics.Pr7CustomList;

import java.util.ArrayList;

public class CustomList <T extends Comparable<T>> {
    private ArrayList<T> list;

    public CustomList() {
        this.list = new ArrayList<>();
    }

    public void add(T value){
        this.list.add(value);
    }

    public T remove (int index){
        return this.list.remove(index);
    }

    public boolean contains (T element){
        return this.list.contains(element);
    }

    public void swap (int index1, int index2){
        T firstElement = this.list.get(index1);
        T secondElement = this.list.get(index2);

        this.list.set(index1,secondElement);
        this.list.set(index2,firstElement);
    }

    public int countGreaterThan (T value) {
        
        int counter = 0;

        for (int i = 0; i < this.list.size(); i++) {
            T element = this.list.get(i);
            if (value.compareTo(element) < 0) {
                counter++;
            }
        }

        return counter;
    }

    public T getMax(){
        if (list.size() == 0) throw new IllegalArgumentException();

        T max = this.list.get(0);

        for (int i = 0; i < this.list.size(); i++) {
            if (max.compareTo(this.list.get(i)) < 0) {
                max = this.list.get(i);
            }
        }

        return max;
    }

    public T getMin(){
        if (this.list.size() == 0) throw new IllegalArgumentException();

        T min = this.list.get(0);

        for (int i = 0; i < this.list.size(); i++) {
            if (min.compareTo(this.list.get(i)) > 0){
                min = this.list.get(i);
            }
        }

        return min;
    }

    public void print(){
        this.list.forEach(System.out::println);
    }
}
