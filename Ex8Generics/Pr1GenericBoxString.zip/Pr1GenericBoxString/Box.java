package Ex8Generics.Pr1GenericBoxString;

public class Box<T> {
    private T data;

    public Box(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return this.data.getClass().getName() + ": " + this.data.toString();
    }
}
