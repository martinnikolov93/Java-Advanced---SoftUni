package Ex8Generics.Pr6GenericCountMethodDoubles;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayList<Double> list = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            Double input = Double.parseDouble(scanner.nextLine());

            list.add(input);
        }

        Double value = Double.parseDouble(scanner.nextLine());

        System.out.println(compare(list, value));
    }

    public static <T extends Comparable> int compare (ArrayList<T> list, T value){
        int counter = 0;

        for (int i = 0; i < list.size(); i++) {
            T element = list.get(i);

            if (element.compareTo(value) > 0) {
                counter++;
            }
        }

        return counter;
    }
}
