package Ex8Generics.Pr8CustomListSorter;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CustomList<String> list = new CustomList<>();

        Scanner scanner = new Scanner(System.in);
        String input;

        while (!"END".equals(input  = scanner.nextLine())){

            String[] tokens = input.split(" ");
            String command = tokens[0];
            String secondParameter = "";
            String thirdParameter = "";

            if (tokens.length == 2){
                secondParameter = tokens[1];
            } else if (tokens.length == 3){
                secondParameter = tokens[1];
                thirdParameter = tokens[2];
            }


            switch (command) {

                case "Add":
                    list.add(secondParameter);
                    break;

                case "Remove":
                    list.remove(Integer.parseInt(secondParameter));
                    break;

                case "Contains":
                    System.out.println(list.contains(secondParameter));
                    break;

                case "Swap":
                    list.swap(Integer.parseInt(secondParameter), Integer.parseInt(thirdParameter));
                    break;

                case "Greater":
                    System.out.println(list.countGreaterThan(secondParameter));
                    break;

                case "Max":
                    System.out.println(list.getMax());
                    break;

                case "Min":
                    System.out.println(list.getMin());
                    break;

                case "Sort":
                    Sorter.sort(list);
                    break;

                case "Print":
                    list.print();
                    break;

            }
        }
    }
}
