package Ex8Generics.Pr8CustomListSorter;

import java.util.Collections;

public class Sorter extends CustomList {

    public static CustomList sort (CustomList list) {
        list.sort();
        return list;
    }
}
