package Ex8Generics.Pr5GenericCountMethodStrings;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayList<String> list = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String input = scanner.nextLine();

            list.add(input);
        }

        String value = scanner.nextLine();

        System.out.println(compare(list, value));
    }

    public static <T extends Comparable> int compare (ArrayList<T> list, T value){
        int counter = 0;

        for (int i = 0; i < list.size(); i++) {
            T element = list.get(i);

            if (element.compareTo(value) > 0) {
                counter++;
            }
        }

        return counter;
    }
}
