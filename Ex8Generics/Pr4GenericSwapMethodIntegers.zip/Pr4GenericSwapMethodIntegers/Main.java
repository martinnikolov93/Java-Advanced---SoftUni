package Ex8Generics.Pr4GenericSwapMethodIntegers;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayList<Integer> list = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            list.add(Integer.parseInt(scanner.nextLine()));
        }

        int index1 = scanner.nextInt();
        int index2 = scanner.nextInt();

        swap(list, index1,index2);

        list.forEach(e -> System.out.println(e.getClass().getName() + ": " + e));
    }

    public static <T> ArrayList<T> swap (ArrayList<T> list, int index1, int index2 ) {

        T firstValue = list.get(index1);
        T secondValue = list.get(index2);

        list.set(index1,secondValue);
        list.set(index2,firstValue);

        return list;
    }
}
